# LaTeX source package for the SoftwareX manuscript

## Contents

- `paper_softwarex.tex`: manuscript source with inline bibliography.
- `elsarticle.cls`: official Elsevier elsarticle 3.4 class extracted from the class section of the user-supplied official DTX bundle.
- `softwarex_architecture.pdf`: Figure 1.
- `jwd_map.pdf`: Figure 2.

No original JWD, SLIB or native SHP data are included in this package. The map PDF is a generated output, not an input dataset. No external files are needed to compile the manuscript itself.

## Build

Use a local LaTeX engine. The bibliography is inline, so BibTeX is not required.

With Tectonic 0.17.0:

```bash
tectonic paper_softwarex.tex --outdir . --reruns 2 -Z "search-path=."
```

With pdfLaTeX, run the following command three times:

```bash
pdflatex -interaction=nonstopmode paper_softwarex.tex
```

The generated file must be `paper_softwarex.pdf`. Check the log for `Document Class: elsarticle 2024/04/04, 3.4: Elsevier Ltd`, resolve all references and inspect all pages.

## Provenance

- Official guide supplied by the user as `D:\intro.pdf`, 13 pages, 6,191,726 bytes, SHA-256 `693870930050f13bac58fe8fe4d6c11990f297fe8fc08c045be7236ee1da9e51`.
- Official `elsarticle.zip` supplied by the user as `C:\Users\86182\Downloads\elsarticle.zip`, 1,430,199 bytes, SHA-256 `0b093093e84db49f99bcc9a7c3f69ed1fb61b0147c6d296427aff7963e7f50f6`.
- The class is elsarticle 3.4 dated 2024/04/04. It was extracted deterministically from the `%<*class>` ... `%</class>` section of the official DTX, because the installer did not emit the class under the local Tectonic setup.
- Tectonic 0.17.0 Windows release: SHA-256 `f61ce51f0b0ade1015b7de7ef368541c5424e9756ecbd0d7af97d6d48030845f`.

## Submission boundary

Attach the compiled PDF as item type `Manuscript`. Keep this ZIP as the LaTeX source package for the revision-stage source-file request. Do not add original JWD/SLIB data or the `mapgis2shp_submission` audit workspace to the software distribution.
